---
name: Feature request
about: Suggest an idea for this project

---

<!--
1. Do not delete this template or the issue will be closed
2. Ensure you're using the latest version of Directus
3. Post to the correct repo:
    App:  https://github.com/directus/app/issues
    API:  https://github.com/directus/api/issues (YOU ARE HERE)
    Docs: https://github.com/directus/docs/issues
-->

# Feature Request

## What problem does this feature solve?

## How do you think this should be implemented?

## Would you be willing to work on this?
