<?php

return [
    'provider' => \Directus\Authentication\Sso\Provider\okta\Provider::class
];
