<?php

return [
    'provider' => \Directus\Authentication\Sso\Provider\twitter\Provider::class
];
