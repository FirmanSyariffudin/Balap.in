<?php

namespace Directus\Config;

use Directus\Collection\Collection;

class Config extends Collection implements ConfigInterface
{

}
