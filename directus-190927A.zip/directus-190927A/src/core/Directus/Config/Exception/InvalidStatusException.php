<?php

namespace Directus\Config\Exception;

use Directus\Exception\ErrorException;

class InvalidStatusException extends ErrorException
{

}
