<?php

namespace Directus\Config\Schema\Exception;

use Directus\Exception\ErrorException;

class OmitException extends ErrorException
{

}
