<?php

namespace Directus\Container\Exception;

class ValueNotFoundException extends \InvalidArgumentException
{

}
