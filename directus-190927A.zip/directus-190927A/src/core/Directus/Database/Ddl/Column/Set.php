<?php

namespace Directus\Database\Ddl\Column;

class Set extends CollectionLength
{
    /**
     * @var string
     */
    protected $type = 'SET';
}
