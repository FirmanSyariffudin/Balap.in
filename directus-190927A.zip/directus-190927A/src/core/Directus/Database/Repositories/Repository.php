<?php

namespace Directus\Database\Repositories;

class Repository extends AbstractRepository
{

}
