<?php

namespace Directus\Database\Repositories;

class RepositoryFactory
{
    public static function create()
    {
        // TODO: Create the factory
    }
}
